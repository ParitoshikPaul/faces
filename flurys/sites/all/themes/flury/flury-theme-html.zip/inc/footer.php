
	<div class="footer">
      <!--footer start-->      
      <div class="col-sm-6">
         <!--col-sm-6-menu start-->         
         <ul class="footer-menubar">
            <li><a href="http://reputationindia.net/development/ab/Flury/contact.php">Contact Us</a></li>
            <li><a href="#">Career</a></li>
            <li><a href="http://reputationindia.net/development/ab/Flury/help.php">Help</a></li>
            <li><a href="http://reputationindia.net/development/ab/Flury/terms&conditions.php">Privacy & Terms</a></li>
            <li><a href="#">Testimonials</a></li>
         </ul>
      </div>
      <!--col-sm-6-menu end-->      
      <div class="col-sm-6">
         <!--col-sm-6-social-icon start-->         
         <ul class="social-icon">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
         </ul>
      </div>
      <!--col-sm-6-social-icon end-->   
   </div><!--footer end-->
		</div><!--section-two end-->
    </div><!--section-one end-->
</body>
  <!-- Optional theme -->  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>   
    <link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">
	<script src="js/custom.js"></script>
</html>
