<!DOCTYPE html>
<html>
<head>
   <meta charset=utf-8"/>
   <title>Flurys</title>
   <link href="css/style.css" rel="stylesheet" type="text/css">
   <link href="css/media-screen.css" rel="stylesheet" type="text/css">
   <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
   <!-- Latest compiled and minified CSS -->   
   <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
 
	
   <!-- Latest compiled and minified JavaScript -->

</head>
<body>
	<div class="header">
         <!--header start-->         
         <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1  search-icon">
            <!--search-icon start-->
			<a href="#" class="btn btn-info btn-lg">        
			<span class="glyphicon glyphicon-search"></span>        
			</a>         
         </div>
         <!--search-icon end-->         
         <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 navigation">
            <!--navigation start-->            
            <div class="top-menu">
               <!--top-menu start-->               
               <h4>Welcome back<span>Sangeeta!</span></h4>
               <ul class="account">
                  <li><a href="#">My Account</a></li>
                  <li><a href="#">Favourite Orders</a></li>
                  <li><a href="#">Recent Orders</a></li>
               </ul>
               <div class="clear"></div>
            </div>
            <!--top-menu end-->            
            <div class="bottom-menu">
               <!--bottom-menu start-->               
               <ul class="menubar">
                  <li><a href="http://reputationindia.net/development/ab/Flury/about.php">OUR LEGACY</a></li>
                  <li><a href="http://reputationindia.net/development/ab/Flury/product.php">PRODUCTS</a></li>
                  <li><a href="http://reputationindia.net/development/ab/Flury/our-selection.php">OUR SELECTION</a></li>
                  <li class="logo"><a href="http://reputationindia.net/development/ab/Flury/index.php"><img src="images/logo.png"/></a></li>
                  <li><a href="#">MEDIA</a></li>
                  <li><a href="#">FIND US</a></li>
                  <li><a href="#">CONTACT US</a></li>
               </ul>
            </div>
            <!--bottom-menu end-->	          
         </div>
         <!--navigation end-->         
         <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1  shoping-icon">
            <!--shoping-icon start-->       
			<a href="#" class="btn btn-info btn-lg">       
			<span class="glyphicon glyphicon-shopping-cart"></span>  
			</a>         
         </div>
         <!--shoping-icon start-->      
      </div><!--header start-->     
		

	  
