<?php include "inc/header.php" ?>


   <div class="container-fluid other-pink"><!--container-fluid start-->			
      <h2>SHOPPING BAG</h2>
	  <div class="main-div">
		  <h4>CUSTOMER SERVICE - 0088 234 3002</h4>
		  <div class="col-sm-4">
			<h3>ITEM DESCRIPTION</h3>
		  </div>
		   <div class="col-sm-4">
			<h3>QUANTITY</h3>
		  </div>
		   <div class="col-sm-4">
			<h3>SUB TOTAL</h3>
		  </div>
	  </div>
   </div><!--container-fluid end-->	
  

	 
<?php include "inc/footer.php" ?>