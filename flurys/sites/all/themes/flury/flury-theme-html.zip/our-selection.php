<?php include "inc/header.php" ?>


   <div class="container-fluid other"><!--container-fluid start-->			
      
   </div><!--container-fluid end-->	
  
  <div class="container-fluid cookies">
	 <div class="tea-time col-lg-6 col-md-6 col-sm-6 col-xs-6">
<div id="carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="item active">
                    <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                   <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                    <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                    <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                   <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                    <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                   <img src="images/selection-one.png" alt="" width="462">
                </div>
                <div class="item">
                    <img src="images/selection-one.png" alt="" width="462">
                </div>
            </div>
        </div> 
    <div class="clearfix">
        <div id="thumbcarousel" class="carousel slide" data-interval="false">
            <div class="carousel-inner">
                <div class="item active">
                    <div data-target="#carousel" data-slide-to="0" class="thumb">
						<img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                    <div data-target="#carousel" data-slide-to="1" class="thumb">
					   <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                    <div data-target="#carousel" data-slide-to="2" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                    <div data-target="#carousel" data-slide-to="3" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
					<div data-target="#carousel" data-slide-to="4" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                </div><!-- /item -->
                <div class="item">
					<div data-target="#carousel" data-slide-to="5" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                    <div data-target="#carousel" data-slide-to="6" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                    <div data-target="#carousel" data-slide-to="7" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
					<div data-target="#carousel" data-slide-to="8" class="thumb">
					<img src="images/selection-one-thump.png" alt="" width="80">
					</div>
					<div data-target="#carousel" data-slide-to="9" class="thumb">
					 <img src="images/selection-one-thump.png" alt="" width="80">
					</div>
                </div><!-- /item -->
				</div><!-- /carousel-inner -->
         </div> <!-- /thumbcarousel -->
    </div><!-- /clearfix -->
	</div>
	 <div class="tea-time col-lg-3 col-md-3 col-sm-3 col-xs-3">
		<div class="eggles">
			<h2>Coconut Cookies <span>(eggless)</span></h2>
			<h6>RS. 750*</div>
			<h3>DESCRIPTION</h3>
			<p>This cookie boasts a perfectly dense crumb and flavorful
				bites filled with spice and nuts. Add a dreamy layer of
				maple cream cheese frosting and there’s no going back
				to carrots only in your salads.</p>
			<form method="post" class="entityform">
				<h5>*PRICE AND QUANTITY PER DOZEN</h5>
				<div class="for-selection">
					<label for="Weight">Weight</label>
					<select name="select" id="select" class="form-control form-select">
						<option value="SELECT">SELECT</option>
						<option value="SELECT">SELECT</option>
					</select>
				</div>
				<div class="fr-selection">
					<label for="qty">qty</label>
					<input type="number" name="quantity" min="1" max="5" class="qty">
				</div>
				<input type="submit" value="ADD TO BAG" class="bag">
			</form>
			<ul class="social-icon">
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram"></i></a></li>
				<li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
			</ul>
		</div>
	 <div class="tea-time col-lg-3 col-md-3 col-sm-3 col-xs-3">
		<form method="post" class="entityform">
			<div class="for-selection">
				<label for="Weight">REVIEW THIS PRODUCT</label>
				<textarea class="review"></textarea>
				<input type="submit" value="SUBMIT REVIEW" class="review">
			</div>
		</form>
		<div class="fav-product">
			<h4>CUSTOMER FAVOURITES</h4>
			<ul class="fav-list">
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
			</ul>
			
		</div>
	 </div>
  </div>
  
  <div class="container-fluid new-product"><!--new-product start-->      
      <h2>MIGHT INTEREST YOU!</h2>
       <div class="tea-time col-lg-4 col-md-4 col-sm-4 col-xs-4">
         <!--tea-time start-->        
		 <div class="new-div">	
			<a href="#"><img src="images/product-1.jpg"></a> 
			<div class="tea-hover">
            <!--tea-hover start--> 
				<div class="box-div">
					<a href="#">
						<i class="fa fa-list-ul"></i>
						<h3>VIEW DETAILS</h3>
					</a>
					<a href="#">
						<i class="fa fa-heart-o"></i>
						<h3>ADD TO FAVOURITES</h3>
					</a>
				</div>
			</div>
		</div>        
        <h2>Coconut Cookies <span>(box of 24)</span></h2>
         <h6>Rs. 520</h6>
         <a href="#">ADD TO</a>     
      </div>
      <div class="tea-time col-lg-4 col-md-4 col-sm-4 col-xs-4">
         <!--tea-time start-->        
		 <div class="new-div">	
			<a href="#"><img src="images/product-1.jpg"></a> 
			<div class="tea-hover">
            <!--tea-hover start--> 
				<div class="box-div">
					<a href="#">
						<i class="fa fa-list-ul"></i>
						<h3>VIEW DETAILS</h3>
					</a>
					<a href="#">
						<i class="fa fa-heart-o"></i>
						<h3>ADD TO FAVOURITES</h3>
					</a>
				</div>
			</div>
		</div>        
         <h2>Banana Coffee Cake <span>(250 grams)</span></h2>
         <h6>Rs. 75 per piece</h6>
         <a href="#">ADD TO</a>      
      </div>
      <div class="tea-time col-lg-4 col-md-4 col-sm-4 col-xs-4">
         <!--tea-time start-->        
		 <div class="new-div">	
			<a href="#"><img src="images/product-1.jpg"></a> 
			<div class="tea-hover">
            <!--tea-hover start--> 
				<div class="box-div">
					<a href="#">
						<i class="fa fa-list-ul"></i>
						<h3>VIEW DETAILS</h3>
					</a>
					<a href="#">
						<i class="fa fa-heart-o"></i>
						<h3>ADD TO FAVOURITES</h3>
					</a>
				</div>
			</div>
		</div>        
        <h2>Butter Chocolate Cake <span>(250 grams)</span></h2>
         <h6>Rs. 520</h6>
         <a href="#">ADD TO</a>       
      </div>
   </div>
   
	<div class="container-fluid nav">
		<ul class="nav-div">
			<li><a href="#">DELIVERY INFO <span>orders placed before 3:30pmwill despatch same day</span></a>
			<li><a href="#">RETURNS <span>if you are not 100% satisfied...</span></a>
			<li><a href="#">CONTACT US <span>we are here tohelp</span></a>
			<li><a href="#">GIFT VOUCHERS <span>a little something for someone special</span></a>
			<li><a href="#">INNOVATION <span>process behind flurys creations</span></a>
			<li><a href="#">PROMOTIONS <span>only available right here at flurys.com</span></a>
			</li>
		</ul>
	</div>
	 
<?php include "inc/footer.php" ?>