<?php

/**
 * @file
 * template.php
 */

function faces_preprocess_page(&$variables) {
if (!empty($variables['node']) && !empty($variables['node']->type)) {
$variables['theme_hook_suggestions'][] = 'page__node__' . $variables['node']->type;
}

}
function faces_theme() {
  return array(
    'user_login' => array(
      'template' => 'user-login'
    ),

  );
}
function faces_preprocess_user_login(&$variables) {
	$variables['form'] = drupal_build_form('user_login', user_login(array(),$form_state)); ## I have to build the user login myself.
}

?>