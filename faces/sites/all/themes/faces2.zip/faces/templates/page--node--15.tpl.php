
    <div class="home">
		<?php global $base_url; ?>
		<!----HEADER-->
		<div class="header">
			<div class="container">
				<div class="megamenu_wrapper"><!-- Begin Mega Menu Container -->
				    <ul class="megamenu"><!-- Begin Mega Menu -->
				        <li class="megamenu_button"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/m-logo.png" class="m_logo" alt=""><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu-icon.png" alt=""></li>    
				        <li><span class="drop"><a href="<?php echo $base_url; ?>/content/products">Products</a></span><!-- Begin Item -->
				            <div class="megamenu_fullwidth"><!-- Begin Item Container -->
				   			 	<div class="main_menu">
					   			 	<div class="container">
					   			 		<div class="col-md-3 display_m">
					   			 			<div class="menu_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/menu.jpg" alt=""></div>
					   			 			<div class="menu_text">BESTSELLERS</div>
					   			 		</div>
					   			 		<div class="col-md-9 home_links">
					   			 			<ul  data-color="#747680">
					   			 				<h4 style=" color: #747680;">EYES</h4>
					   			 				<li><a href="#">EYE PENCIL</a></li>
					   			 				<li><a href="#">MASCARA</a></li>
					   			 				<li><a href="#">KAJAL</a></li>
					   			 				<li><a href="#">EYE LINER</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul data-color="#ffcc99">
					   			 				<h4>FACE</h4>
					   			 				<li><a href="#">BLUSH</a></li>
					   			 				<li><a href="#">CC CREAM</a></li>
					   			 				<li><a href="#">CONCEALER</a></li>
					   			 				<li><a href="#">FOUNDATION</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul  data-color="#fe0101">
					   			 				<h4>LIPS</h4>
					   			 				<li><a href="#">LIP CREME</li>
					   			 				<li><a href="#">LIP GLOSS</a></li>
					   			 				<li><a href="#">LIPSTICK</a></li>
					   			 			
					   			 			</ul>	
					   			 			<ul  data-color="#01feef">
					   			 				<h4>SKIN</h4>
					   			 				<li><a href="#">CLEANSER</li>
					   			 				<li><a href="#">MAKEUP REMOVER</a></li>
					   			 				<li><a href="#">TONER</a></li>
					   			 				
					   			 			</ul>
					   			 			<ul  data-color="#fd03f4" >
					   			 				<h4>NAILS</h4>
					   			 				<li><a href="#">NAIL ENAMEL</a></li>
					   			 				<li><a href="#">NAIL ENAMEL REMOVER</a></li>
					   			 			
					   			 			</ul>		
					   			 		</div>
					   			 	</div><div class="clr"></div>
				   			 	</div> <div class="clr"></div>
				   			 	<div class="menu_border">
				   			 		
				   			 	</div>      
				            </div><!-- End Item Container -->
				        </li><!-- End Item -->
				        <li><a href="<?php echo $base_url; ?>/content/hot-deals">Hot Deals</a></li> 
				        <li><a href="<?php echo $base_url; ?>/content/about-us">About Us</a></li>
				   <?php if ($logo): ?>	<li class="for_logo display_m"><a href="<?php echo $base_url; ?>"><img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /></a></li> <?php endif; ?>
						<li><a href="<?php echo $base_url; ?>/content/best-seller">BESTSELLER </a></li>
				       	<li><a href="<?php echo $base_url; ?>/content/tips-tricks">LOOKS & TIPS</a> </li>
				       	<li><a href="<?php echo $base_url; ?>/content/our-stores">STORE LOCATOR</a></li>
				       
				    </ul><div class="clr"></div>
				</div><!-- End Mega Menu Container -->
				

			</div>
		</div>
	<div id="home_second" >
		<div class="container border">
		<div class="row" data-sr="no reset">
				<div class="col-md-12 about_img">
					<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/tipstricks.png" alt="">
				</div>
		</div>
			<div class="about">
				<div class="col-xs-12 col-sm-12 col-md-3 about_left" data-sr="no reset">
					<div class="about_faces"><?php $title =$node->title; echo $title; dpm($node->body['und'][0]['safe_summary']); ?></div>
					<div class="about_tab">
						<ul class="tabs">
							<li><a rel="tab1" href="javascript:void(0)">ABOUT US <span>+</span></a></li>
							<li><a rel="tab2" href="javascript:void(0)">OUR STORY <span>+</span></a></li>
							<li><a rel="tab3" href="javascript:void(0)">OUR PEOPLE <span>+</span></a></li>
						</ul>	
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab1" >
					<h2>About Us</h2>
					<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                            			</div>
                 <div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab2" >
					<h2>Our Story</h2>
						<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                   </div>  
                <div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab3" >
				
					<h2>Our People</h2>
						<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                   </div>   
				
				<div class="clr"></div>
			</div>
		</div>
	</div>
	        <div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	
	
