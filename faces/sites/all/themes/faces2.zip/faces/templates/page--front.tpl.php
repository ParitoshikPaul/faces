
    <div class="home">
		<?php global $base_url; ?>
		<!----HEADER-->

		<div class="header">
		<a href="#menu"></a>
	
			<div class="container">
			
				<div class="megamenu_wrapper"><!-- Begin Mega Menu Container -->
				    <ul class="megamenu"><!-- Begin Mega Menu -->
				        <li class="megamenu_button"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/m-logo.png" class="m_logo" alt=""><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu-icon.png" alt=""></li>    
				        <li><span class="drop"><a href="<?php echo $base_url; ?>/content/products">Products</a></span><!-- Begin Item -->
				            <div class="megamenu_fullwidth"><!-- Begin Item Container -->
				   			 	<div class="main_menu">
					   			 	<div class="container">
					   			 		<div class="col-md-3 display_m">
					   			 			<div class="menu_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/menu.jpg" alt=""></div>
					   			 			<div class="menu_text">BESTSELLERS</div>
					   			 		</div>
					   			 		<div class="col-md-9 home_links">
					   			 			<ul  data-color="#747680">
					   			 				<h4 style=" color: #747680;">EYES</h4>
					   			 				<li><a href="#">EYE PENCIL</a></li>
					   			 				<li><a href="#">MASCARA</a></li>
					   			 				<li><a href="#">KAJAL</a></li>
					   			 				<li><a href="#">EYE LINER</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul data-color="#ffcc99">
					   			 				<h4>FACE</h4>
					   			 				<li><a href="#">BLUSH</a></li>
					   			 				<li><a href="#">CC CREAM</a></li>
					   			 				<li><a href="#">CONCEALER</a></li>
					   			 				<li><a href="#">FOUNDATION</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul  data-color="#fe0101">
					   			 				<h4>LIPS</h4>
					   			 				<li><a href="#">LIP CREME</li>
					   			 				<li><a href="#">LIP GLOSS</a></li>
					   			 				<li><a href="#">LIPSTICK</a></li>
					   			 			
					   			 			</ul>	
					   			 			<ul  data-color="#01feef">
					   			 				<h4>SKIN</h4>
					   			 				<li><a href="#">CLEANSER</li>
					   			 				<li><a href="#">MAKEUP REMOVER</a></li>
					   			 				<li><a href="#">TONER</a></li>
					   			 				
					   			 			</ul>
					   			 			<ul  data-color="#fd03f4" >
					   			 				<h4>NAILS</h4>
					   			 				<li><a href="#">NAIL ENAMEL</a></li>
					   			 				<li><a href="#">NAIL ENAMEL REMOVER</a></li>
					   			 			
					   			 			</ul>		
					   			 		</div>
					   			 	</div><div class="clr"></div>
				   			 	</div> <div class="clr"></div>
				   			 	<div class="menu_border">
				   			 		
				   			 	</div>      
				            </div><!-- End Item Container -->
				        </li><!-- End Item -->
				        <li><a href="<?php echo $base_url; ?>/content/hot-deals">Hot Deals</a></li> 
				        <li><a href="<?php echo $base_url; ?>/content/about-us">About Us</a></li>
				   <?php if ($logo): ?>	<li class="for_logo display_m"><a href="<?php echo $base_url; ?>"><img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /></a></li> <?php endif; ?>
						<li><a href="<?php echo $base_url; ?>/content/best-seller">BESTSELLER </a></li>
				       	<li><a href="<?php echo $base_url; ?>/content/tips-tricks">LOOKS & TIPS</a> </li>
				       	<li><a href="<?php echo $base_url; ?>/content/our-stores">STORE LOCATOR</a></li>  
				       
				    </ul><div class="clr"></div>
				</div><!-- End Mega Menu Container -->
				 

			</div>
<div class="banner-cont">
  <div class="plus">
	    	<img src=" <?php global $base_url; ?>sites/all/themes/faces/img/plus.png" alt="">
	    </div>
    		<ul class="home-slider">
			<?php $slide_node = node_load_multiple(array(), array('type' => 'home_page_slides'));
			foreach($slide_node as $slides):
			$file_url = file_create_url($slides->field_slide_image['und'][0]['uri']);
			?>
				<li><img src="<?php echo $file_url; ?>" alt="" /></li>
			<?php endforeach; ?>
    	    </ul>
    
	</div>
	</div>
	<!---HOME BOTTOM PART-->
		<div id="home_second" >
		<div class="footer">
			<div class="container">
			<div class="footer_left">
				<ul>
				<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
		</div>
		<div class="container border">
			<div class="home_main" data-sr="no reset" >
				
					<div class="show" >
				<?php $body_text = theme_get_setting('tag_desc'); 
					  print($body_text);
				?>
			
					
				</div>
				<div class="home_image" data-sr="no reset">
					<div class="home_image_left">
						<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/home_small.png" alt="">
					</div>
					<div class="home_image_right">
    					<div class="flip-container" ontouchstart="this.classList.toggle('hover');">
    						<div class="flipper">
        						<div class="front-side">
        						<a href="<?php $link_url = theme_get_setting('banner-image-link-url'); print($link_url);?>"><span><?php $link_text = theme_get_setting('banner-image-link-text'); print($link_text);?> </span><br/><?php $desc_text = theme_get_setting('banner-image-link-desc'); print($desc_text);?></a>
        				         </div>
        				        <div class="back-side">
                        			<a href=""><h1 style="color:#fff;">Comming Soon</h1></a>
                        		</div>
    				         </div>
    				    </div>
					</div>
					<div class="clr"></div>
				</div>
			</div>
			</div>
		       <!---FOOTER MAIN-->
			<div class="footer_main">
				<div class="footer_first" data-sr="no reset" >
					
						<?php print render($page['menulist']);?>
					
				
				
				</div><div class="clr"></div>
				<div class="footer_second" data-sr="no reset" >
					<div class="subscriber">
						<p>By subscribing to our mailing list you will always <br />
                         be update with the latest news from us.</p>
                         <form>
                         	<input type="text" name="subscriber" value="" placeholder="Enter yor email" />
                         	<input type="submit" value="submit" name="ssubmit" />
                         </form>	
					</div>
					<div class="footer_logo">
						<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/footer_logo.png" alt="">
					</div><div class="clr"></div>
				</div>
				
			</div><div class="clr"></div>

	
	<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="<?php $fb_url = theme_get_setting('facebook_url'); echo $fb_url; ?>"><i class="fa fa-facebook"></i></a>
				<a href="<?php $tw_url = theme_get_setting('twitter_url'); echo $tw_url; ?>"><i class="fa fa-twitter"></i></a>
				<a href="<?php $in_url = theme_get_setting('instagram_url'); echo $tw_url; ?>"><i class="fa fa-instagram"></i></a>
				<a href="<?php $pin_url = theme_get_setting('pintrest_url'); echo $tw_url; ?>"><i class="fa fa-pinterest"></i></a>
				<a href="<?php $gplus_url = theme_get_setting('googleplus_url'); echo $tw_url; ?>"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
		<!----FOOTER-->
	</div>

