
    <div class="home">
		<?php global $base_url; ?>
		<!----HEADER-->
		<div class="header">
			<div class="container">
				<div class="megamenu_wrapper"><!-- Begin Mega Menu Container -->
				    <ul class="megamenu"><!-- Begin Mega Menu -->
				        <li class="megamenu_button"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/m-logo.png" class="m_logo" alt=""><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu-icon.png" alt=""></li>    
				        <li><span class="drop"><a href="products">Products</a></span><!-- Begin Item -->
				            <div class="megamenu_fullwidth"><!-- Begin Item Container -->
				   			 	<div class="main_menu">
					   			 	<div class="container">
					   			 		<div class="col-md-3 display_m">
					   			 			<div class="menu_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu.jpg" alt=""></div>
					   			 			<div class="menu_text">BESTSELLERS</div>
					   			 		</div>
					   			 		<div class="col-md-9 home_links">
					   			 			<ul  data-color="#a71e3b">
					   			 				<h4 style=" color: #a71e3b;">EYES</h4>
					   			 				<li><a href="#">EYE PENCIL</a></li>
					   			 				<li><a href="#">MASCARA</a></li>
					   			 				<li><a href="#">KAJAL</a></li>
					   			 				<li><a href="#">EYE LINER</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul data-color="#eabf9f">
					   			 				<h4>FACE</h4>
					   			 				<li><a href="#">BLUSH</a></li>
					   			 				<li><a href="#">CC CREAM</a></li>
					   			 				<li><a href="#">CONCEALER</a></li>
					   			 				<li><a href="#">FOUNDATION</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul  data-color="#e32726">
					   			 				<h4>LIPS</h4>
					   			 				<li><a href="#">LIP CREME</li>
					   			 				<li><a href="#">LIP GLOSS</a></li>
					   			 				<li><a href="#">LIPSTICK</a></li>
					   			 			
					   			 			</ul>	
					   			 			<ul  data-color="#028342">
					   			 				<h4>SKIN</h4>
					   			 				<li><a href="#">CLEANSER</li>
					   			 				<li><a href="#">MAKEUP REMOVER</a></li>
					   			 				<li><a href="#">TONER</a></li>
					   			 				
					   			 			</ul>
					   			 			<ul  data-color="#ec008c" >
					   			 				<h4>NAILS</h4>
					   			 				<li><a href="#">NAIL ENAMEL</a></li>
					   			 				<li><a href="#">NAIL ENAMEL REMOVER</a></li>
					   			 			
					   			 			</ul>		
					   			 		</div>
					   			 	</div><div class="clr"></div>
				   			 	</div> <div class="clr"></div>
				   			 	<div class="menu_border">
				   			 		
				   			 	</div>      
				            </div><!-- End Item Container -->
				        </li><!-- End Item -->
				        <li><a href="hot-deals">Hot Deals</a></li> 
				        <li><a href="about-us">About Us</a></li>
				   <?php if ($logo): ?>	<li class="for_logo display_m"><a href="<?php echo $base_url; ?>"><img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /></a></li> <?php endif; ?>
						<li><a href="best-seller">BESTSELLER </a></li>
				       	<li><a href="tips-tricks">TIPS & TRICKS</a> </li>
				       	<li><a href="our-stores">STORE LOCATOR</a></li>
				       
				    </ul><div class="clr"></div> 
				</div><!-- End Mega Menu Container -->
				

			</div>
		</div>
	<div id="home_second" >
		<div class="container border">
		<div class="row" data-sr="no reset">
				<div class="col-md-12 about_img">
					<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/about-img.png" alt="">
				</div>
		</div>
			<div class="about">
			
				<div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab1" >
					<h2>Login</h2>
					<?php  print render($tabs); print render($page['content']); ?>
					 			
				
				<div class="clr"></div>
			</div>
		</div>
	</div>
	        <div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
	  
	        $('.plus').on('click',function(){
	            $('html, body').animate({scrollTop: $("#home_second").offset().top}, 1000);
	            $('.footer').hide('slow');
	            $('#home_second').css('padding-top', '8%');
	        });

	      /***********ONSCROLL****/
	        $(window).scroll(function() {

		    if ($(this).scrollTop()>0)
		     {
		        $('.footer').fadeOut();
		     }
		    else
		     {
		        $('.footer').fadeIn();
		     }
		 });
	      /************MENU HOVER***************/
	   $('.home_links ul').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).data('color');
	   	$('.menu_border').css('background', dataColor);
	   	$('.menu_img').css('background', dataColor);
	   	
	   }, function() {
	   	/* Stuff to do when the mouse leaves the element */
	   });

	   $('.home_links ul li a').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).parents('ul').data('color');
	   	selectedList.css('color', dataColor);
	   }, function() {
	   		selectedList = $(this);
	   		selectedList.css('color', 'black');
	   });
	    /***********************READ MORE**************/

		$(function() {
		var showTotalChar = 730, showChar = "+", hideChar = "-";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		    $(this).html(txt);
		    }
		    });
		    $(".showmoretxt").click(function() {
		    if ($(this).hasClass("sample")) {
		    	$(this).removeClass("sample");
		   	 	$(this).text(showChar);
		    	$('morectnt').css('margin-top', '20px');
		    } else {
		    	$(this).addClass("sample");
		    	$(this).text(hideChar);
		    }
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    return false;
		    });
		    });
           /***********************ABOUT PAGE TAB**************/
          
		      $(".about_text").hide();
		      $(".about_text:first").show(); 
		      $(".tabs li:first-child").addClass("active");

		      $("ul.tabs li a").click(function() {
		          $(".about_text").hide();
		           var activeTab = $(this).attr("rel"); 
		          $("#"+activeTab).fadeIn(700); 
		          $("ul.tabs li a").removeClass("active");
		          $('ul.tabs li a').find('span').removeClass("active").text('+');
		          $(this).find('span').removeClass("active").text('-');
		          $(this).addClass("active");
		    });

		      /*****************************ReVeal*****************/
		        (function($) {

		        'use strict';

		        window.sr= new scrollReveal({
		          reset: true,
		          move: '50px',
		          mobile: true
		        });

		      })();

		      /**************************************SLIDER******************/
		      $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});
			 $('.bxslider2').bxSlider({
	       mode:'fade',
			  auto: true,
			  autoControls: true,
			  pager:false
			});

	   
	</script>
	
