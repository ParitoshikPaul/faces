
    <div class="home">
		<?php global $base_url; ?>
		<!----HEADER-->
		<div class="header">
			<div class="container">
				<div class="megamenu_wrapper"><!-- Begin Mega Menu Container -->
				    <ul class="megamenu"><!-- Begin Mega Menu -->
				        <li class="megamenu_button"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/m-logo.png" class="m_logo" alt=""><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu-icon.png" alt=""></li>    
				        <li><span class="drop"><a href="<?php echo $base_url; ?>/content/products">Products</a></span><!-- Begin Item -->
				            <div class="megamenu_fullwidth"><!-- Begin Item Container -->
				   			 	<div class="main_menu">
					   			 	<div class="container">
					   			 		<div class="col-md-3 display_m">
					   			 			<div class="menu_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/menu.jpg" alt=""></div>
					   			 			<div class="menu_text">BESTSELLERS</div>
					   			 		</div>
					   			 		<div class="col-md-9 home_links">
					   			 			<ul  data-color="#747680">
					   			 				<h4 style=" color: #747680;">EYES</h4>
					   			 				<li><a href="#">EYE PENCIL</a></li>
					   			 				<li><a href="#">MASCARA</a></li>
					   			 				<li><a href="#">KAJAL</a></li>
					   			 				<li><a href="#">EYE LINER</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul data-color="#ffcc99">
					   			 				<h4>FACE</h4>
					   			 				<li><a href="#">BLUSH</a></li>
					   			 				<li><a href="#">CC CREAM</a></li>
					   			 				<li><a href="#">CONCEALER</a></li>
					   			 				<li><a href="#">FOUNDATION</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul  data-color="#fe0101">
					   			 				<h4>LIPS</h4>
					   			 				<li><a href="#">LIP CREME</li>
					   			 				<li><a href="#">LIP GLOSS</a></li>
					   			 				<li><a href="#">LIPSTICK</a></li>
					   			 			
					   			 			</ul>	
					   			 			<ul  data-color="#01feef">
					   			 				<h4>SKIN</h4>
					   			 				<li><a href="#">CLEANSER</li>
					   			 				<li><a href="#">MAKEUP REMOVER</a></li>
					   			 				<li><a href="#">TONER</a></li>
					   			 				
					   			 			</ul>
					   			 			<ul  data-color="#fd03f4" >
					   			 				<h4>NAILS</h4>
					   			 				<li><a href="#">NAIL ENAMEL</a></li>
					   			 				<li><a href="#">NAIL ENAMEL REMOVER</a></li>
					   			 			
					   			 			</ul>		
					   			 		</div>
					   			 	</div><div class="clr"></div>
				   			 	</div> <div class="clr"></div>
				   			 	<div class="menu_border">
				   			 		
				   			 	</div>      
				            </div><!-- End Item Container -->
				        </li><!-- End Item -->
				        <li><a href="<?php echo $base_url; ?>/content/hot-deals">Hot Deals</a></li> 
				        <li><a href="<?php echo $base_url; ?>/content/about-us">About Us</a></li>
				   <?php if ($logo): ?>	<li class="for_logo display_m"><a href="<?php echo $base_url; ?>"><img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /></a></li> <?php endif; ?>
						<li><a href="<?php echo $base_url; ?>/content/best-seller">BESTSELLER </a></li>
				       	<li><a href="<?php echo $base_url; ?>/content/tips-tricks">LOOKS & TIPS</a> </li>
				       	<li><a href="<?php echo $base_url; ?>/content/our-stores">STORE LOCATOR</a></li>
				       
				    </ul><div class="clr"></div>
				</div><!-- End Mega Menu Container -->
				

			</div>
    
	</div>
	<!---HOME BOTTOM PART-->
	<div id="home_second" >
	
		<div class="footer">
			<div class="container">
			<div class="footer_left">
				<ul>
				<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
		</div>
		<div class="container border">
		<div class="row product_inner">
				<div class="col-xs-12 col-sm-12 col-md-4">
					<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product-inner.png" alt="">
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6">
					<div class="product_info">
						<div class="heading"><?php echo $node->title; ?></div>
						<div class="product_price">
							<div class="left">PRICE :</div>
							<div class="right">RS. 1,500</div><div class="clr"></div>
						</div>
						<div class="product_shades">
							<div class="left">ALL SHADES :</div>
							<div class="right">
								<ul>
									<li>asd</li>
									<li>s</li>
									<li>s</li>
									<li>d</li>
									<li>f</li>
								</ul>	
							</div><div class="clr"></div>
						</div>
						<div class="product_shadename">
							<div class="left">SHADE :</div>
							<div class="right"> PEACHY PINK</div><div class="clr"></div>
						</div>
						<div class="buy_now">
							<button>Buy Now</button>
						</div>
						<div class="product_text">
							<h5>PRODUCT DESCRIPTION</h5>
							<p>Matte finish for the uber chic! A vivid color burst that lasts more than 8 hours. Enriched with Vitamin E and anti-aging oxidants. Creamy texture gives smooth, water proof high coverage. Available in a range of swanky shades. </p>
						</div>
					</div>
					
				</div>
				<div class="col-xs-12 col-sm-12 col-md-2">
					<div class="might_like">
						<h3>You Might Like</h3>
						<div class="like_main">
							<div class="like_image"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/porduct_inner1.png" alt=""></div>
							<div class="like_description">
								Glam On Noir Eyeliner
							</div>
						</div>
						<div class="like_main">
							<div class="like_image"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/porduct_inner1.png" alt=""></div>
							<div class="like_description">
								Glam On Noir Eyeliner
							</div>
						</div>
						<div class="like_main">
							<div class="like_image"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/porduct_inner1.png" alt=""></div>
							<div class="like_description">
								Glam On Noir Eyeliner
							</div>
						</div>
					</div>
				
				</div>
			</div>
		       <!---FOOTER MAIN-->
			<div class="footer_main">
				<div class="footer_first" data-sr="no reset" >
					
						<?php print render($page['menulist']);?>
					
				
				
				</div><div class="clr"></div>
				<div class="footer_second" data-sr="no reset" >
					<div class="subscriber">
						<p>By subscribing to our mailing list you will always <br />
                         be update with the latest news from us.</p>
                         <form>
                         	<input type="text" name="subscriber" value="" placeholder="Enter yor email" />
                         	<input type="submit" value="submit" name="ssubmit" />
                         </form>	
					</div>
					<div class="footer_logo">
						<img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/footer_logo.png" alt="">
					</div><div class="clr"></div>
				</div>
				
			</div><div class="clr"></div>

	<script type="text/javascript">
	  
	        $('.plus').on('click',function(){
	            $('html, body').animate({scrollTop: $("#home_second").offset().top}, 1000);
	            $('.footer').hide('slow');
	            $('#home_second').css('padding-top', '8%');
	        });

	      /***********ONSCROLL****/
	        $(window).scroll(function() {

		    if ($(this).scrollTop()>0)
		     {
		        $('.footer').fadeOut();
		     }
		    else
		     {
		        $('.footer').fadeIn();
		     }
		 });
	      /************MENU HOVER***************/
	   $('.home_links ul').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).data('color');
	   	$('.menu_border').css('background', dataColor);
	   	$('.menu_img').css('background', dataColor);
	   	
	   }, function() {
	   	/* Stuff to do when the mouse leaves the element */
	   });

	   $('.home_links ul li a').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).parents('ul').data('color');
	   	selectedList.css('color', dataColor);
	   }, function() {
	   		selectedList = $(this);
	   		selectedList.css('color', 'black');
	   });
	    /***********************READ MORE**************/

		$(function() {
		var showTotalChar = 730, showChar = "+", hideChar = "-";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		    $(this).html(txt);
		    }
		    });
		    $(".showmoretxt").click(function() {
		    if ($(this).hasClass("sample")) {
		    	$(this).removeClass("sample");
		   	 	$(this).text(showChar);
		    	$('morectnt').css('margin-top', '20px');
		    } else {
		    	$(this).addClass("sample");
		    	$(this).text(hideChar);
		    }
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    return false;
		    });
		    });
           /***********************ABOUT PAGE TAB**************/
          
		      $(".about_text").hide();
		      $(".about_text:first").show(); 
		      $(".tabs li:first-child").addClass("active");

		      $("ul.tabs li a").click(function() {
		          $(".about_text").hide();
		           var activeTab = $(this).attr("rel"); 
		          $("#"+activeTab).fadeIn(700); 
		          $("ul.tabs li a").removeClass("active");
		          $('ul.tabs li a').find('span').removeClass("active").text('+');
		          $(this).find('span').removeClass("active").text('-');
		          $(this).addClass("active");
		    });

		      /*****************************ReVeal*****************/
		        (function($) {

		        'use strict';

		        window.sr= new scrollReveal({
		          reset: true,
		          move: '50px',
		          mobile: true
		        });

		      })();

		      /**************************************SLIDER******************/
		      $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});
			 $('.bxslider2').bxSlider({
	       mode:'fade',
			  auto: true,
			  autoControls: true,
			  pager:false
			});
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide"
  });
});
	   
	</script>
	<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="<?php $fb_url = theme_get_setting('facebook_url'); echo $fb_url; ?>"><i class="fa fa-facebook"></i></a>
				<a href="<?php $tw_url = theme_get_setting('twitter_url'); echo $tw_url; ?>"><i class="fa fa-twitter"></i></a>
				<a href="<?php $in_url = theme_get_setting('instagram_url'); echo $tw_url; ?>"><i class="fa fa-instagram"></i></a>
				<a href="<?php $pin_url = theme_get_setting('pintrest_url'); echo $tw_url; ?>"><i class="fa fa-pinterest"></i></a>
				<a href="<?php $gplus_url = theme_get_setting('googleplus_url'); echo $tw_url; ?>"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
		
		<!----FOOTER-->
	
	</div>

	
		<script type="text/javascript">
			
			jQuery(function($){
				
				jQuery.supersized({
				
					// Functionality
					slide_interval          :   3000,		// Length between transitions
					transition              :   3, 			// 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
					transition_speed		:	700,		// Speed of transition
															   
					// Components							
					slide_links				:	'blank',	// Individual links for each slide (Options: false, 'num', 'name', 'blank')
					slides 					:  	[			// Slideshow Images
														{image : 'http://localhost/codiad/workspace/faces/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg'},
														{image : 'http://localhost/codiad/workspace/faces/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg'},
														{image : 'http://localhost/codiad/workspace/faces/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg'},
														
												]
					
				});
		    });
		    
	</script>
	 <script>
        jQuery(document).ready(function ($) {

            var _CaptionTransitions = [];
            _CaptionTransitions["L"] = { $Duration: 900, x: 0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
            _CaptionTransitions["R"] = { $Duration: 900, x: -0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
            _CaptionTransitions["T"] = { $Duration: 900, y: 0.6, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
            _CaptionTransitions["B"] = { $Duration: 900, y: -0.6, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
            _CaptionTransitions["ZMF|10"] = { $Duration: 900, $Zoom: 11, $Easing: { $Zoom: $JssorEasing$.$EaseOutQuad, $Opacity: $JssorEasing$.$EaseLinear }, $Opacity: 2 };
            _CaptionTransitions["RTT|10"] = { $Duration: 900, $Zoom: 11, $Rotate: 1, $Easing: { $Zoom: $JssorEasing$.$EaseOutQuad, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInExpo }, $Opacity: 2, $Round: { $Rotate: 0.8} };
            _CaptionTransitions["RTT|2"] = { $Duration: 900, $Zoom: 3, $Rotate: 1, $Easing: { $Zoom: $JssorEasing$.$EaseInQuad, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInQuad }, $Opacity: 2, $Round: { $Rotate: 0.5} };
            _CaptionTransitions["RTTL|BR"] = { $Duration: 900, x: -0.6, y: -0.6, $Zoom: 11, $Rotate: 1, $Easing: { $Left: $JssorEasing$.$EaseInCubic, $Top: $JssorEasing$.$EaseInCubic, $Zoom: $JssorEasing$.$EaseInCubic, $Opacity: $JssorEasing$.$EaseLinear, $Rotate: $JssorEasing$.$EaseInCubic }, $Opacity: 2, $Round: { $Rotate: 0.8} };
            _CaptionTransitions["CLIP|LR"] = { $Duration: 900, $Clip: 15, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic }, $Opacity: 2 };
            _CaptionTransitions["MCLIP|L"] = { $Duration: 900, $Clip: 1, $Move: true, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic} };
            _CaptionTransitions["MCLIP|R"] = { $Duration: 900, $Clip: 2, $Move: true, $Easing: { $Clip: $JssorEasing$.$EaseInOutCubic} };

            var options = {
                $FillMode: 2,                                       //[Optional] The way to fill image in slide, 0 stretch, 1 contain (keep aspect ratio and put all inside slide), 2 cover (keep aspect ratio and cover whole slide), 4 actual size, 5 contain for large image, actual size for small image, default value is 0
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlayInterval: 4000,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $PauseOnHover: 1,                                   //[Optional] Whether to pause when mouse over if a slider is auto playing, 0 no pause, 1 pause for desktop, 2 pause for touch device, 3 pause for desktop and touch device, 4 freeze for desktop, 8 freeze for touch device, 12 freeze for desktop and touch device, default value is 1

                $ArrowKeyNavigation: true,   			            //[Optional] Allows keyboard (arrow key) navigation or not, default value is false
                $SlideEasing: $JssorEasing$.$EaseOutQuint,          //[Optional] Specifies easing for right to left animation, default value is $JssorEasing$.$EaseOutQuad
                $SlideDuration: 800,                               //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $MinDragOffsetToSlide: 20,                          //[Optional] Minimum drag offset to trigger slide , default value is 20
                //$SlideWidth: 600,                                 //[Optional] Width of every slide in pixels, default value is width of 'slides' container
                //$SlideHeight: 300,                                //[Optional] Height of every slide in pixels, default value is height of 'slides' container
                $SlideSpacing: 0, 					                //[Optional] Space between each slide in pixels, default value is 0
                $DisplayPieces: 1,                                  //[Optional] Number of pieces to display (the slideshow would be disabled if the value is set to greater than 1), the default value is 1
                $ParkingPosition: 0,                                //[Optional] The offset position to park slide (this options applys only when slideshow disabled), default value is 0.
                $UISearchMode: 1,                                   //[Optional] The way (0 parellel, 1 recursive, default value is 1) to search UI components (slides container, loading screen, navigator container, arrow navigator container, thumbnail navigator container etc).
                $PlayOrientation: 1,                                //[Optional] Orientation to play slide (for auto play, navigation), 1 horizental, 2 vertical, 5 horizental reverse, 6 vertical reverse, default value is 1
                $DragOrientation: 1,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)

                $CaptionSliderOptions: {                            //[Optional] Options which specifies how to animate caption
                    $Class: $JssorCaptionSlider$,                   //[Required] Class to create instance to animate caption
                    $CaptionTransitions: _CaptionTransitions,       //[Required] An array of caption transitions to play caption, see caption transition section at jssor slideshow transition builder
                    $PlayInMode: 1,                                 //[Optional] 0 None (no play), 1 Chain (goes after main slide), 3 Chain Flatten (goes after main slide and flatten all caption animations), default value is 1
                    $PlayOutMode: 3                                 //[Optional] 0 None (no play), 1 Chain (goes before main slide), 3 Chain Flatten (goes before main slide and flatten all caption animations), default value is 1
                },

                $BulletNavigatorOptions: {                          //[Optional] Options to specify and enable navigator or not
                    $Class: $JssorBulletNavigator$,                 //[Required] Class to create navigator instance
                    $ChanceToShow: 2,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 1,                                 //[Optional] Auto center navigator in parent container, 0 None, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1,                                      //[Optional] Steps to go for each navigation request, default value is 1
                    $Lanes: 1,                                      //[Optional] Specify lanes to arrange items, default value is 1
                    $SpacingX: 8,                                   //[Optional] Horizontal space between each item in pixel, default value is 0
                    $SpacingY: 8,                                   //[Optional] Vertical space between each item in pixel, default value is 0
                    $Orientation: 1                                 //[Optional] The orientation of the navigator, 1 horizontal, 2 vertical, default value is 1
                },

                $ArrowNavigatorOptions: {                           //[Optional] Options to specify and enable arrow navigator or not
                    $Class: $JssorArrowNavigator$,                  //[Requried] Class to create arrow navigator instance
                    $ChanceToShow: 1,                               //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 2,                                 //[Optional] Auto center arrows in parent container, 0 No, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1                                       //[Optional] Steps to go for each navigation request, default value is 1
                }
            };

            var jssor_slider1 = new $JssorSlider$("slider1_container", options);

            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizes
            function ScaleSlider() {
                var bodyWidth = document.body.clientWidth;
                if (bodyWidth)
                    jssor_slider1.$ScaleWidth(Math.min(bodyWidth, 1920));
                else
                    window.setTimeout(ScaleSlider, 30);
            }
            ScaleSlider();

            $(window).bind("load", ScaleSlider);
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
            //responsive code end
        });
    </script>
	
