
    <div class="home">
		<?php global $base_url; ?>
		<!----HEADER-->
		<div class="header">
			<div class="container">
				<div class="megamenu_wrapper"><!-- Begin Mega Menu Container -->
				    <ul class="megamenu"><!-- Begin Mega Menu -->
				        <li class="megamenu_button"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/m-logo.png" class="m_logo" alt=""><img src="<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/menu-icon.png" alt=""></li>    
				        <li><span class="drop"><a href="content/products">Products</a></span><!-- Begin Item -->
				            <div class="megamenu_fullwidth"><!-- Begin Item Container -->
				   			 	<div class="main_menu">
					   			 	<div class="container">
					   			 		<div class="col-md-3 display_m">
					   			 			<div class="menu_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/menu.jpg" alt=""></div>
					   			 			<div class="menu_text">BESTSELLERS</div>
					   			 		</div>
					   			 		<div class="col-md-9 home_links">
					   			 			<ul  data-color="#a71e3b">
					   			 				<h4 style=" color: #a71e3b;">EYES</h4>
					   			 				<li><a href="#">EYE PENCIL</a></li>
					   			 				<li><a href="#">MASCARA</a></li>
					   			 				<li><a href="#">KAJAL</a></li>
					   			 				<li><a href="#">EYE LINER</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul data-color="#eabf9f">
					   			 				<h4>FACE</h4>
					   			 				<li><a href="#">BLUSH</a></li>
					   			 				<li><a href="#">CC CREAM</a></li>
					   			 				<li><a href="#">CONCEALER</a></li>
					   			 				<li><a href="#">FOUNDATION</a></li>
					   			 				
					   			 			</ul>	
					   			 			<ul  data-color="#e32726">
					   			 				<h4>LIPS</h4>
					   			 				<li><a href="#">LIP CREME</li>
					   			 				<li><a href="#">LIP GLOSS</a></li>
					   			 				<li><a href="#">LIPSTICK</a></li>
					   			 			
					   			 			</ul>	
					   			 			<ul  data-color="#028342">
					   			 				<h4>SKIN</h4>
					   			 				<li><a href="#">CLEANSER</li>
					   			 				<li><a href="#">MAKEUP REMOVER</a></li>
					   			 				<li><a href="#">TONER</a></li>
					   			 				
					   			 			</ul>
					   			 			<ul  data-color="#ec008c" >
					   			 				<h4>NAILS</h4>
					   			 				<li><a href="#">NAIL ENAMEL</a></li>
					   			 				<li><a href="#">NAIL ENAMEL REMOVER</a></li>
					   			 			
					   			 			</ul>		
					   			 		</div>
					   			 	</div><div class="clr"></div>
				   			 	</div> <div class="clr"></div>
				   			 	<div class="menu_border">
				   			 		
				   			 	</div>      
				            </div><!-- End Item Container -->
				        </li><!-- End Item -->
				        <li><a href="content/hot-deals">Hot Deals</a></li> 
				        <li><a href="content/about-us">About Us</a></li>
				   <?php if ($logo): ?>	<li class="for_logo display_m"><a href="<?php echo $base_url; ?>"><img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" /></a></li> <?php endif; ?>
						<li><a href="content/best-seller">BESTSELLER </a></li>
				       	<li><a href="content/tips-tricks">TIPS & TRICKS</a> </li>
				       	<li><a href="content/our-stores">STORE LOCATOR</a></li>
				       
				    </ul><div class="clr"></div>
				</div><!-- End Mega Menu Container -->
				

			</div>