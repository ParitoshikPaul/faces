<?php

/**
 * @file
 * template.php
 */

function faces_preprocess_page(&$variables) {
if (!empty($variables['node']) && !empty($variables['node']->type)) {
$variables['theme_hook_suggestions'][] = 'page__node__' . $variables['node']->type;
}

}

?>