<?php global $base_url; ?>
	<div id="home_second" >
		<div class="container border">
			<div class="featured-deals product_img">
				<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/hot-deals.png" />
				<div class="feat-prod-detail">
				<h1>Magneteyes Kajal</h1>
				<p>20% Off on more that 4 buys</p>
				</div>
			</div>
			<div class="featured-deals product_img">
				<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/hot-deals.png" />
				<div class="feat-prod-detail">
				<h1>Magneteyes Kajal</h1>
				<p>20% Off on more that 4 buys</p>
				</div>
			</div>
			<div class="featured-deals product_img">
				<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/hot-deals.png" />
				<div class="feat-prod-detail">
				<h1>Magneteyes Kajal</h1>
				<p>20% Off on more that 4 buys</p>
				</div>
			</div>
		</div>
	</div>

		<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	
