<div class="foooter_links">
<h2><?php print render($block->subject); ?></h2>
<?php print render($content); ?>
</div>