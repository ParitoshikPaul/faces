<?php global $base_url; ?>
	<div id="home_second" >
		<div class="container border">
			<!---PRODUCTS SLIDER-->
			<div class="products_slider">
			<?php global $base_url; ?>
				<ul class="bxslider">
				  <li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/about-img.png" alt="" /></li>
				  <li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/about-img.png" alt="" /></li>
				  <li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/about-img.png" alt="" /></li>
				</ul>
			</div>	
			
			<!---PRODUCTS NAVBAR-->
			<div class="navbar_line"></div>
			<div class="navbar_main">
				<div class="navbar_links">
					<a href="#">LONG LASTING</a>
					<a href="#">SHINY</a>
					<a href="#">MATTE</a>
					<a href="#">LONG LASTING</a>
					<a href="#">POP</a>

				</div>
			</div>

			<!---PRODUCTS OPTIONS-->
			<div class="row products_option ">
				<div class=" col-xs-12 col-sm-12  col-md-2 limiter">
					<label>
					Filter :
					    <select>
					        <option selected> 12 </option>
					        <option>4</option>
					        <option>5</option>
					    </select>
				    </label>
				</div>
				<div class=" col-xs-12 col-sm-12  col-md-2 limiter">
					<label>
					    <select>
					        <option selected> Type </option>
					        <option>4</option>
					        <option>5</option>
					    </select>
				    </label>
				</div>
				<div class="col-xs-12 col-sm-12  col-md-2 limiter">
					<label>
					    <select>
					        <option selected> Color</option>
					        <option>4</option>
					        <option>5</option>
					    </select>
				    </label>
				</div>
			</div>

			<!---PRODUCTS-->
			<div class="row products">
		<?php print render($page['content']); ?>
				
			</div>

		</div>
	</div>
		 

	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.bxslider.js"></script>
	<script src="js/scrollReveal.min.js"></script>
	<script type="text/javascript">
	  
	        $('.plus').on('click',function(){
	            $('html, body').animate({scrollTop: $("#home_second").offset().top}, 1000);
	            $('.footer').hide('slow');
	            $('#home_second').css('padding-top', '8%');
	        });

	      /***********ONSCROLL****/
	        $(window).scroll(function() {

		    if ($(this).scrollTop()>0)
		     {
		        $('.footer').fadeOut();
		     }
		    else
		     {
		        $('.footer').fadeIn();
		     }
		 });
	      /************MENU HOVER***************/
	   $('.home_links ul').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).data('color');
	   	$('.menu_border').css('background', dataColor);
	   	$('.menu_img').css('background', dataColor);
	   	
	   }, function() {
	   	/* Stuff to do when the mouse leaves the element */
	   });

	   $('.home_links ul li a').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).parents('ul').data('color');
	   	selectedList.css('color', dataColor);
	   }, function() {
	   		selectedList = $(this);
	   		selectedList.css('color', 'black');
	   });
	    /***********************READ MORE**************/

		$(function() {
		var showTotalChar = 730, showChar = "+", hideChar = "-";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		    $(this).html(txt);
		    }
		    });
		    $(".showmoretxt").click(function() {
		    if ($(this).hasClass("sample")) {
		    	$(this).removeClass("sample");
		   	 	$(this).text(showChar);
		    	$('morectnt').css('margin-top', '20px');
		    } else {
		    	$(this).addClass("sample");
		    	$(this).text(hideChar);
		    }
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    return false;
		    });
		    });
           /***********************ABOUT PAGE TAB**************/
          
		      $(".about_text").hide();
		      $(".about_text:first").show(); 
		      $(".tabs li:first-child").addClass("active");

		      $("ul.tabs li a").click(function() {
		          $(".about_text").hide();
		           var activeTab = $(this).attr("rel"); 
		          $("#"+activeTab).fadeIn(700); 
		          $("ul.tabs li a").removeClass("active");
		          $('ul.tabs li a').find('span').removeClass("active").text('+');
		          $(this).find('span').removeClass("active").text('-');
		          $(this).addClass("active");
		    });

		      /*****************************ReVeal*****************/
		        (function($) {

		        'use strict';

		        window.sr= new scrollReveal({
		          reset: true,
		          move: '50px',
		          mobile: true
		        });

		      })();

		      /**************************************SLIDER******************/
		      $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});

	   
	</script>
	

    


	<script src="js/megamenu.js"></script><!-- Mega Menu Script -->
	<script>
	$(document).ready(function($){
	    $('#megamenu_form').ajaxForm({target:'#alert'}); 
		$('.megamenu').megaMenuReloaded({
	        menu_speed_show : 300, // Time (in milliseconds) to show a drop down
	        menu_speed_hide : 200, // Time (in milliseconds) to hide a drop down
	        menu_speed_delay : 200, // Time (in milliseconds) before showing a drop down
	        menu_effect : 'open_close_slide', // Drop down effect, choose between 'hover_fade', 'hover_slide', 'click_fade', 'click_slide', 'open_close_fade', 'open_close_slide'
	        menu_easing : 'jswing', // Easing Effect : 'easeInQuad', 'easeInElastic', etc.
	        menu_click_outside : 1, // Clicks outside the drop down close it (1 = true, 0 = false)
	        menu_show_onload : 0, // Drop down to show on page load (type the number of the drop down, 0 for none)
	        menubar_trigger : 1, // Show the menu trigger (button to show / hide the menu bar), only for the fixed version of the menu (1 = show, 0 = hide)
	        menubar_hide : 0, // Hides the menu bar on load (1 = hide, 0 = show)
	        menu_responsive : 1, // Enables mobile-specific script
	        menu_carousel : 0, // Enable / disable carousel
	        menu_carousel_groups : 0 // Number of groups of elements in the carousel
		});
	});
	</script>

	
		
	
		<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	
	
	
	
	<!---SLIDER SCRIPT-->
	<script type="text/javascript" src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/supersized.3.2.7.min.js"></script>
	<script type="text/javascript" src="js/supersized.shutter.min.js"></script>
    <script src="js/bootstrap.min.js"></script>	
	<script type="text/javascript">
			
			jQuery(function($){
				
				$.supersized({
				
					// Functionality
					slide_interval          :   3000,		// Length between transitions
					transition              :   3, 			// 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
					transition_speed		:	700,		// Speed of transition
															   
					// Components							
					slide_links				:	'blank',	// Individual links for each slide (Options: false, 'num', 'name', 'blank')
					slides 					:  	[			// Slideshow Images
														{image : '<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/slider/home.jpg'},
														{image : '<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/slider/home.jpg'},
														{image : '<?php echo $base_url; ?>/sites/all/themes/faces/<?php echo $base_url; ?>/sites/all/themes/faces/img/slider/home.jpg'},
														
												]
					
				});
		    });
		    
	</script>
