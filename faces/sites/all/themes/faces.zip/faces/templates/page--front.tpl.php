
  <?php global $base_url; ?> 
  <div class="banner-cont">
  <div class="plus">
	    	<img src=" <?php global $base_url; ?>sites/all/themes/faces/img/plus.png" alt="">
	    </div>
    		<ul class="bxslider">
    		<li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg" alt="" /></li>
    		<li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg" alt="" /></li>
    		<li><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/home.jpg" alt="" /></li>
    	    </ul>
    </div>
	</div>
	<!---HOME BOTTOM PART-->
	<div id="home_second" >
	
		<div class="footer">
			<div class="container">
			<div class="footer_left">
				<ul>
				<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
		</div>
		<div class="container border">
			<div class="home_main" data-sr="no reset" >
				
					<div class="show" >
				<?php $body_text = theme_get_setting('tag_desc'); 
					  print($body_text);
				?>
			
					
				</div>
				<div class="home_image" data-sr="no reset">
					<div class="home_image_left">
						<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/home_small.png" alt="">
					</div>
					<div class="home_image_right">
    					<div class="flip-container" ontouchstart="this.classList.toggle('hover');">
    						<div class="flipper">
        						<div class="front-side">
        						<a href="<?php $link_url = theme_get_setting('banner-image-link-url'); print($link_url);?>"><span><?php $link_text = theme_get_setting('banner-image-link-text'); print($link_text);?> </span><br/><?php $desc_text = theme_get_setting('banner-image-link-desc'); print($desc_text);?></a>
        				         </div>
        				        <div class="back-side">
                        			<a href=""><h1 style="color:#fff;">Comming Soon</h1></a>
                        		</div>
    				         </div>
    				    </div>
					</div>
					<div class="clr"></div>
				</div>
			</div>
			</div>
		       <!---FOOTER MAIN-->
			<div class="footer_main">
				<div class="footer_first" data-sr="no reset" >
					
						<?php print render($page['menulist']);?>
					
				
				
				</div><div class="clr"></div>
				<div class="footer_second" data-sr="no reset" >
					<div class="subscriber">
						<p>By subscribing to our mailing list you will always <br />
                         be update with the latest news from us.</p>
                         <form>
                         	<input type="text" name="subscriber" value="" placeholder="Enter yor email" />
                         	<input type="submit" value="submit" name="ssubmit" />
                         </form>	
					</div>
					<div class="footer_logo">
						<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/footer_logo.png" alt="">
					</div><div class="clr"></div>
				</div>
				
			</div><div class="clr"></div>

	<script type="text/javascript">
	  
	        $('.plus').on('click',function(){
	            $('html, body').animate({scrollTop: $("#home_second").offset().top}, 1000);
	         //   $('.footer').hide('slow');
	            $('#home_second').css('padding-top', '8%');
	        });

	      /***********ONSCROLL****/
// 	        $(window).scroll(function() {

// 		    if ($(this).scrollTop()>0)
// 		     {
// 		        $('.footer').fadeOut();
// 		     }
// 		    else
// 		     {
// 		        $('.footer').fadeIn();
// 		     }
// 		 });
	      /************MENU HOVER***************/
	   $('.home_links ul').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).data('color');
	   	$('.menu_border').css('background', dataColor);
	   	$('.menu_img').css('background', dataColor);
	   	
	   }, function() {
	   	/* Stuff to do when the mouse leaves the element */
	   });

	   $('.home_links ul li a').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).parents('ul').data('color');
	   	selectedList.css('color', dataColor);
	   }, function() {
	   		selectedList = $(this);
	   		selectedList.css('color', 'black');
	   });
	    /***********************READ MORE**************/

		$(function() {
		var showTotalChar = 730, showChar = "+", hideChar = "-";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		    $(this).html(txt);
		    }
		    });
		    $(".showmoretxt").click(function() {
		    if ($(this).hasClass("sample")) {
		    	$(this).removeClass("sample");
		   	 	$(this).text(showChar);
		    	$('morectnt').css('margin-top', '20px');
		    } else {
		    	$(this).addClass("sample");
		    	$(this).text(hideChar);
		    }
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    return false;
		    });
		    });
           /***********************ABOUT PAGE TAB**************/
          
		      $(".about_text").hide();
		      $(".about_text:first").show(); 
		      $(".tabs li:first-child").addClass("active");

		      $("ul.tabs li a").click(function() {
		          $(".about_text").hide();
		           var activeTab = $(this).attr("rel"); 
		          $("#"+activeTab).fadeIn(700); 
		          $("ul.tabs li a").removeClass("active");
		          $('ul.tabs li a').find('span').removeClass("active").text('+');
		          $(this).find('span').removeClass("active").text('-');
		          $(this).addClass("active");
		    });

		      /*****************************ReVeal*****************/
		        (function($) {

		        'use strict';

		        window.sr= new scrollReveal({
		          reset: true,
		          move: '50px',
		          mobile: true
		        });

		      })();

		      /**************************************SLIDER******************/
		      $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});
		

	   
	</script>
	<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="<?php $fb_url = theme_get_setting('facebook_url'); echo $fb_url; ?>"><i class="fa fa-facebook"></i></a>
				<a href="<?php $tw_url = theme_get_setting('twitter_url'); echo $tw_url; ?>"><i class="fa fa-twitter"></i></a>
				<a href="<?php $in_url = theme_get_setting('instagram_url'); echo $tw_url; ?>"><i class="fa fa-instagram"></i></a>
				<a href="<?php $pin_url = theme_get_setting('pintrest_url'); echo $tw_url; ?>"><i class="fa fa-pinterest"></i></a>
				<a href="<?php $gplus_url = theme_get_setting('googleplus_url'); echo $tw_url; ?>"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
		<!----FOOTER-->
	</div>

