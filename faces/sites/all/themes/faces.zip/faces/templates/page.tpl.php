<?php global $base_url; ?>
	<div id="home_second" >
		<div class="container border">
		<div class="row" data-sr="no reset">
				<div class="col-md-12 about_img">
					<img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/about-img.png" alt="">
				</div>
		</div>
			<div class="about">
				<div class="col-xs-12 col-sm-12 col-md-3 about_left" data-sr="no reset">
					<div class="about_faces"><?php $title =$node->title; echo $title; dpm($node->body['und'][0]['safe_summary']); ?></div>
					<div class="about_tab">
						<ul class="tabs">
							<li><a rel="tab1" href="javascript:void(0)">ABOUT US <span>+</span></a></li>
							<li><a rel="tab2" href="javascript:void(0)">OUR STORY <span>+</span></a></li>
							<li><a rel="tab3" href="javascript:void(0)">OUR PEOPLE <span>+</span></a></li>
						</ul>	
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab1" >
					<h2>About Us</h2>
					<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                            			</div>
                 <div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab2" >
					<h2>Our Story</h2>
						<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                   </div>  
                <div class="col-xs-12 col-sm-12 col-md-9 about_text" id="tab3" >
				
					<h2>Our People</h2>
						<?php  print render($tabs);  ?>
					<p>
                        FACES Cosmetics, with a proud Canadian heritage spanning over 38 years, offers an exclusive line of makeup, skincare products and personal care accessories. FACES offer unparalleled variety in its products, which are designed to suit every ethnicity, skin type and tone, complexion and texture. Not tested on animals, FACES products are hypoallergenic and conform to the most stringent quality and safety requirements. FACES products are globally acclaimed and are available at attractive price points in all its markets from North America to India. The wide assortment of shades, textures and designs helps the FACES consumers capture every look and style, right from casual to professional to glamorous. FACES recently launched their SILK range of premium international makeup. SILK is a luxurious experience in makeup, that’s designed to create maximum impact. Rich, vibrant and sensuous, SILK is what every woman deserves.
                        
                        Headquartered in Toronto, Canada since being established in 1974, FACES now has a steadily growing international presence. FACES operates a state- of- the- art R&D and product testing facility at Toronto, while its products are manufactured in North America, Europe and Asia. An experienced quality assurance team in Toronto helps ensure uniform product quality conforming to FACES’ own stringent specifications all over the world. Since launching in India in January 2009, FACES has rapidly expanded to over 35 cities across India.
                        
                        FACES range of beauty solutions is available at leading retail outlets all over India, and at FACES exclusive outlets in most major cities of India. </p>
                   </div>   			
				
				<div class="clr"></div>
			</div>
		</div>
	</div>
	        <div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
	  
	        $('.plus').on('click',function(){
	            $('html, body').animate({scrollTop: $("#home_second").offset().top}, 1000);
	            $('.footer').hide('slow');
	            $('#home_second').css('padding-top', '8%');
	        });

	      /***********ONSCROLL****/
	        $(window).scroll(function() {

		    if ($(this).scrollTop()>0)
		     {
		        $('.footer').fadeOut();
		     }
		    else
		     {
		        $('.footer').fadeIn();
		     }
		 });
	      /************MENU HOVER***************/
	   $('.home_links ul').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).data('color');
	   	$('.menu_border').css('background', dataColor);
	   	$('.menu_img').css('background', dataColor);
	   	
	   }, function() {
	   	/* Stuff to do when the mouse leaves the element */
	   });

	   $('.home_links ul li a').hover(function() {
	   	selectedList = $(this);
	   	dataColor = $(this).parents('ul').data('color');
	   	selectedList.css('color', dataColor);
	   }, function() {
	   		selectedList = $(this);
	   		selectedList.css('color', 'black');
	   });
	    /***********************READ MORE**************/

		$(function() {
		var showTotalChar = 730, showChar = "+", hideChar = "-";
		$('.show').each(function() {
		var content = $(this).text();
		if (content.length > showTotalChar) {
		var con = content.substr(0, showTotalChar);
		var hcon = content.substr(showTotalChar, content.length - showTotalChar);
		var txt= con +  '<span class="dots">...</span><span class="morectnt"><span>' + hcon + '</span>&nbsp;&nbsp;<a href="" class="showmoretxt">' + showChar + '</a></span>';
		    $(this).html(txt);
		    }
		    });
		    $(".showmoretxt").click(function() {
		    if ($(this).hasClass("sample")) {
		    	$(this).removeClass("sample");
		   	 	$(this).text(showChar);
		    	$('morectnt').css('margin-top', '20px');
		    } else {
		    	$(this).addClass("sample");
		    	$(this).text(hideChar);
		    }
		    	$(this).parent().prev().toggle();
		    	$(this).prev().toggle();
		    return false;
		    });
		    });
           /***********************ABOUT PAGE TAB**************/
          
		      $(".about_text").hide();
		      $(".about_text:first").show(); 
		      $(".tabs li:first-child").addClass("active");

		      $("ul.tabs li a").click(function() {
		          $(".about_text").hide();
		           var activeTab = $(this).attr("rel"); 
		          $("#"+activeTab).fadeIn(700); 
		          $("ul.tabs li a").removeClass("active");
		          $('ul.tabs li a').find('span').removeClass("active").text('+');
		          $(this).find('span').removeClass("active").text('-');
		          $(this).addClass("active");
		    });

		      /*****************************ReVeal*****************/
		        (function($) {

		        'use strict';

		        window.sr= new scrollReveal({
		          reset: true,
		          move: '50px',
		          mobile: true
		        });

		      })();

		      /**************************************SLIDER******************/
		      $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});
			 $('.bxslider2').bxSlider({
	       mode:'fade',
			  auto: true,
			  autoControls: true,
			  pager:false
			});

	   
	</script>
	
