<?php global $base_url; ?>
	<div id="home_second" >
		<div class="container border best-seller">
				<div class="row products">
				<ul class="bxslider">
				<li>
				<div class=" col-xs-12 col-sm-12 col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
			
				<div class="col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
			
				<div class="col-xs-12 col-sm-12  col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
				</li>
				<li>
				<div class=" col-xs-12 col-sm-12 col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
			
				<div class="col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
			
				<div class="col-xs-12 col-sm-12  col-md-4">
					<div class="product_img"><img src="<?php echo $base_url; ?>/sites/all/themes/faces/img/product_img.png" alt=""></div>
					<div class="product_descriptions">
						<h2>FACES Ultime ProVelvet Matte</h2>
						<span>THIS IS THE DESCRIPT OR LINE.</span>
						<div class="button_main">
							<button class="button button--rayen button--border-medium button--text-thin button--size-l button--inverted" data-text="BUY NOW"><span>BUY NOW</span></button>
						</div>
					</div>
				</div>
				</li>
				</ul>
		
			</div>
		</div>
	</div>
		<div class="footer_bottom" data-sr="no reset" >
		    <div class="container">
			<div class="footer_left">
				<ul>
			<?php print render($page['footer-menu']);?>
				</ul>	
			</div>
			<div class="footer_right">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
		</div>
	</div>
	<script>    $('.bxslider').bxSlider({
			  auto: true,
			  autoControls: true,
			  pager:false
			});
			 $('.bxslider2').bxSlider({
	       mode:'fade',
			  auto: true,
			  autoControls: true,
			  pager:false
			});</script>
	